# Reporting Security Issues

[Report Vulnerability to the Node Security Project](mailto:report@nodesecurity.io?cc=lancestout@gmail.com&subject=Security%20Issue%20for%20Stanza.io)

In the interest of responsible disclosure, please use the above to report any security issues so
that the appropriate patches and advisories can be made.

## History

No security issues have been reported for this project yet.
